﻿namespace ArmyOfCreatures.Logic
{
    public interface ILogger
    {
        void WriteLine(string line);
    }
}

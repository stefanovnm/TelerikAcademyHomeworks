using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.EncodingSum
{
    class EncodingSum
    {
        static void Main()
        {
            int M = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();
            char current = ' ';
            int result = 0;
            int i = 0;
            

            while (true)
            {
                //Console.WriteLine(input.Length);
                if (i == input.Length)
                {
                    break;
                }
                current = input[i];
                if (current == '@')
                {
                    break;
                }
                if (current >= 48 && current <= 57)//0-9
                {
                    result = result * ((int)current-48);
                   // Console.WriteLine(result);
                }
                else
                {
                    if (current >= 65 && current <= 90)//A-Z
                    {
                        result = result + current - 65;
                       // Console.WriteLine(result);
                    }
                    else
                    {
                        if (current >= 97 && current <= 122)//a-z
                        {
                            result = result + current - 97;
                           // Console.WriteLine(result);
                        }
                        else
                        {
                            result = result % M;
                          //  Console.WriteLine(result);
                        }
                    }
  
                }

                
                if (true)
                {
                    
                }
                i++;
            }
            Console.WriteLine(result);
        }
    }
     
}
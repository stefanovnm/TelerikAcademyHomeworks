using System;
using System.Threading;

namespace _01.MoneyDescription
{
    class MoneyDescription
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
            int N = int.Parse(Console.ReadLine());
            int S = int.Parse(Console.ReadLine());
            double P = double.Parse(Console.ReadLine());
            Console.WriteLine("{0:0.000}",(double)N*(double)S/400*P);
        }
    }
}

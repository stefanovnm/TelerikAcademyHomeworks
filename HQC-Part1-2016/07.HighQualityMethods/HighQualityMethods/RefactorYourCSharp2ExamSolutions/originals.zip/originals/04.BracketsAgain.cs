﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _04.BracketsAgain
{
    class BracketsAgain
    {

        static void Main()
        {
            int rowNumbers = int.Parse(Console.ReadLine());
            string[] rows = new string[rowNumbers];

            for (int i = 0; i < rows.Length; i++)
            {
                rows[i] = Console.ReadLine();
            }

            int countMethods = -1;

            string currentString = string.Empty;
            //Dictionary<string,string> methods = new Dictionary<string, string>();

            List<string> methods = new List<string>();

            //method
            for (int i = 0; i < rows.Length; i++)
            {
                if (rows[i].IndexOf(" static ") != -1)
                {
                    currentString = rows[i].Substring(rows[i].IndexOf(" static ") + 8, rows[i].IndexOf("(") - rows[i].IndexOf(" static ") - 8);

                    while (currentString.IndexOf(" ") != -1)
                    {
                        currentString = currentString.Substring(currentString.IndexOf(" ") + 1, currentString.Length - currentString.IndexOf(" ") - 1);
                    }

                    methods.Add(currentString);

                    countMethods++;
                }
            }
            //Console.WriteLine(countMethods);
            //for method invoke
            string[] invoke = new string[countMethods + 1];

            countMethods = -1;

            for (int i = 0; i < rows.Length; i++)
            {
                if (rows[i].IndexOf(" static ") != -1)
                {
                    currentString = rows[i].Substring(rows[i].IndexOf(" static ") + 8, rows[i].IndexOf("(") - rows[i].IndexOf(" static ") - 8);

                    while (currentString.IndexOf(" ") != -1)
                    {
                        currentString = currentString.Substring(currentString.IndexOf(" ") + 1, currentString.Length - currentString.IndexOf(" ") - 1);
                    }
                    countMethods++;
                }
                if (countMethods > 0)
                {
                    for (int j = 0; j < countMethods; j++)
                    {
                        if (rows[i].IndexOf(methods[j]) != -1)
                        {
                            invoke[countMethods] = invoke[countMethods] + ", " + methods[j];
                        }
                    }
                }




                string row = rows[i];

                if (row.IndexOf(".") != -1 && row.IndexOf("(") != -1 && row.IndexOf(".") < row.IndexOf("("))
                {
                    string temp = row.Substring(row.IndexOf(".") + 1, row.IndexOf("(") - row.IndexOf(".") - 1);
                    if (temp.IndexOf(" ") == -1)
                    {
                        invoke[countMethods] = invoke[countMethods] + ", " + temp;
                    }
                    string rest = row.Substring(row.IndexOf("(") + 1, row.Length - row.IndexOf("(") - 1);
                    if (rest.IndexOf(".") != -1 && rest.IndexOf("(") != -1 && rest.IndexOf(".") < rest.IndexOf("("))
                    {
                        temp = rest.Substring(rest.IndexOf(".") + 1, rest.IndexOf("(") - rest.IndexOf(".") - 1);
                        if (temp.IndexOf(" ") == -1)
                        {
                            invoke[countMethods] = invoke[countMethods] + ", " + temp;
                        }
                    }
                    //Console.WriteLine(invoke[countMethods]);
                }

                //check for "(" first
                while (row.IndexOf("(") < row.IndexOf(".") && row.IndexOf("(") != -1 && row.IndexOf(".") != -1)
                {
                    row = row.Substring(row.IndexOf("(") + 1, row.Length - row.IndexOf("(") - 1);

                    if (row.IndexOf(".") != -1 && row.IndexOf("(") != -1 && row.IndexOf(".") < row.IndexOf("("))
                    {
                        string temp = row.Substring(row.IndexOf(".") + 1, row.IndexOf("(") - row.IndexOf(".") - 1);

                        if (temp.IndexOf(" ") == -1)
                        {
                            invoke[countMethods] = invoke[countMethods] + ", " + temp;
                        }

                        string rest = row.Substring(row.IndexOf("(") + 1, row.Length - row.IndexOf("(") - 1);

                        if (rest.IndexOf(".") != -1 && rest.IndexOf("(") != -1 && rest.IndexOf(".") < rest.IndexOf("("))
                        {
                            temp = rest.Substring(rest.IndexOf(".") + 1, rest.IndexOf("(") - rest.IndexOf(".") - 1);
                            if (temp.IndexOf(" ") == -1)
                            {
                                invoke[countMethods] = invoke[countMethods] + ", " + temp;
                            }
                        }
                    }




                }


            }

            for (int i = 0; i < methods.Count; i++)
            {
                Console.Write(methods[i]);
                if (invoke[i] == string.Empty)
                {
                    Console.WriteLine(" -> None");
                }
                else
                {
                    Console.WriteLine(" -> {0}", invoke[i].Substring(2, invoke[i].Length - 2));
                }
            }

        }
    }
}

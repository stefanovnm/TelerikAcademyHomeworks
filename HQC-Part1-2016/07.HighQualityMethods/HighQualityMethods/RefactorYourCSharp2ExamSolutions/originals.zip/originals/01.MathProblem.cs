﻿using System;
using System.Linq;

namespace _01.MathProblem
{
    class Program
    {

        static int Power(int number, int deg)
        {
            int result = number;
            for (int i = 0; i < deg; i++)
            {
                result *= 19;
            }
            return result;
        }

        static int Input()
        {
            string[] input = Console.ReadLine()
                .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            int sum = 0;

            int counter = 0;
            foreach (var item in input)
            {
                for (int i = 0; i < item.Length; i++)
                {
                    sum += Power((int)(item[i]) - 97, item.Length - 1 - counter);

                    counter++;
                    if (i == item.Length - 1)
                    {
                        counter = 0;
                    }
                }
            }

            return sum;
        }

        static string DecToNineteenth(int number)
        {
            int temp = number;
            string result = "";
            while (temp > 0)
            {
                char current = (char)(temp % 19 + 97);
                result = current + result;
                temp = temp / 19;
            }
            return result;
        }

        static void Main(string[] args)
        {
            int sum = Input();
            Console.WriteLine("{0} = {1}", DecToNineteenth(sum), sum);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03.BishopPathFinder
{
    class BishopPathFinder
    {
        static int[,] Fulfill(int[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    if (j == 0)
                    {
                        if (i == 0)
                        {
                            array[i, j] = (array.GetLength(0) - 1) * 3;
                        }
                        else
                        {
                            array[i, j] = array[i - 1, j] - 3;
                        }
                    }
                    else
                    {
                        array[i, j] = array[i, j - 1] + 3;
                    }
                }
            }

            return array;
        }
        static bool[,] FulfillBool(bool[,] array)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    array[i, j] = false;
                }
            }
            return array;
        }

        static int AvaibleMoves(int[,] array, int i, int j, string dir)
        {
            int able = 0;
            if (dir == "RU" || dir == "UR")
            {
                able = Math.Min(i, array.GetLength(1) - 1 - j);
                //Console.WriteLine("{0},{1}", i,array.GetLength(1) - 1 - j);
            }

            if (dir == "LU" || dir == "UL")
            {
                able = Math.Min(i, j);
                //Console.WriteLine("{0},{1}", i,j);
            }

            if (dir == "RD" || dir == "DR")
            {
                able = Math.Min(array.GetLength(0) - 1 - i, array.GetLength(1) - 1 - j);
                //Console.WriteLine("{0},{1}", array.GetLength(0) - 1 - i, array.GetLength(1) - 1 - j);
            }

            if (dir == "LD" || dir == "DL")
            {
                able = Math.Min(array.GetLength(0) - 1 - i, j);
                //Console.WriteLine("{0},{1}", array.GetLength(0) - 1 - i,j);
            }

            return able;
        }

        static int MoveI(int i, string dir)
        {
            if (dir == "RU" || dir == "UR")
            {
                i--;
            }

            if (dir == "LU" || dir == "UL")
            {
                i--;
            }

            if (dir == "RD" || dir == "DR")
            {
                i++;
            }

            if (dir == "LD" || dir == "DL")
            {
                i++;
            }

            return i;
        }
        static int MoveJ(int j, string dir)
        {
            if (dir == "RU" || dir == "UR")
            {
                j++;
            }

            if (dir == "LU" || dir == "UL")
            {
                j--;
            }

            if (dir == "RD" || dir == "DR")
            {
                j++;
            }

            if (dir == "LD" || dir == "DL")
            {
                j--;
            }
            return j;
        }



        static void Main()
        {
            int[] size = Console.ReadLine()
                .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => int.Parse(x))
                .ToArray();
            int count = int.Parse(Console.ReadLine());
            var moves = new List<Tuple<string, int>>();
            for (int k = 0; k < count; k++)
            {
                string current = Console.ReadLine();
                moves.Add(new Tuple<string, int>(current.Substring(0, 2), int.Parse(current.Substring(2, current.Length - 2))));
            }

            /* foreach (var item in moves)
             {
                 Console.WriteLine("{0} : {1}",item.Item1,item.Item2);
             }*/
            int[,] array = new int[size[0], size[1]];
            array = Fulfill(array);
            bool[,] boolArray = new bool[size[0], size[1]];
            boolArray = FulfillBool(boolArray);

            int i = array.GetLength(0) - 1;
            int j = 0;

            int sum = 0;

            foreach (var item in moves)
            {

                int avaiableMoves = Math.Min(item.Item2 - 1, AvaibleMoves(array, i, j, item.Item1));
                while (avaiableMoves > 0)
                {
                    i = MoveI(i, item.Item1);
                    j = MoveJ(j, item.Item1);

                    if (boolArray[i, j] == false)
                    {
                        sum += array[i, j];
                        boolArray[i, j] = true;
                    }

                    avaiableMoves--;
                }

            }
            Console.WriteLine(sum);

        }
    }
}
﻿using System;

using Moq;
using SchoolSystem.Core;
using NUnit.Framework;

namespace SchoolSystem.Tests
{
    [TestFixture]
    public class EngineClassTests
    {
       
    }
}

﻿using System;

using SchoolSystem.Models;
using NUnit.Framework;

namespace SchoolSystem.Tests
{
    [TestFixture]
    public class TeacherClassTests
    {
        [Test]
        public void Teacher_Constructor_ShouldReturnObjectWithClassStudent()
        {
            Assert.IsInstanceOf<Teacher>(new Teacher("first", "last", Subject.Bulgarian));
        }

        [Test]
        public void Teacher_ShouldThrw_IfNameIsTooShort()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new Teacher("a", "test", Subject.Bulgarian));
        }

        [Test]
        public void Teacher_ShouldThrow_IfNameIsTooLong()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new Teacher("aaaabbbbaaaabbbbaaaabbbbaaaabbbbaaaabbbb", "test", Subject.Bulgarian));
        }

        [Test]
        public void Teacher_ShouldThrow_IfNameContainsSymbolWhichIsNotLetter()
        {
            Assert.Throws<ArgumentException>(() => new Teacher("Test1", "Test", Subject.Bulgarian));
        }


    }
}

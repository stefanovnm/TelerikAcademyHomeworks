function solve() {
    return function (fileContentsByName) {
        // you solution
    }
}

if (typeof module !== 'undefined') {
    module.exports = solve;
}
/* globals document, window, console */

function solve() {
    return function(selector, initialSuggestions) {
    };
}

module.exports = solve;